## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(scMaSigPro)

## ----eval=FALSE---------------------------------------------------------------
#  # Use public PAT
#  publicPat <- "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"
#  
#  # Install devtools if not already installed
#  if (!requireNamespace("devtools", quietly = TRUE)) {
#    install.packages("devtools")
#  }
#  
#  # Install scMaSigPro
#  devtools::install_github("spriyansh/scMaSigPro",
#    ref = "main",
#    auth_token = publicPat,
#    build_vignettes = TRUE,
#    build_manual = TRUE,
#    upgrade = "never",
#    force = TRUE,
#    quiet = TRUE,
#  )

## ----eval=FALSE---------------------------------------------------------------
#  set.seed(123)

## ----eval=FALSE---------------------------------------------------------------
#  library(scMaSigPro)
#  data("splat.sim", package = "scMaSigPro")

## ----eval=FALSE---------------------------------------------------------------
#  scmp.sce <- as_scmp(
#    object = splat.sim, from = "sce",
#    align_pseudotime = FALSE,
#    verbose = FALSE,
#    additional_params = list(
#      labels_exist = TRUE,
#      existing_pseudotime_colname = "Step",
#      existing_path_colname = "Group"
#    )
#  )
#  showParams(scmp.sce, return = TRUE, view = FALSE)

