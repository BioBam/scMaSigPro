# # tests/testthat.R
# library(testthat)
# library(scMaSigPro)
# test_check("scMaSigPro")
